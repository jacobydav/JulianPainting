var searchData=
[
  ['timestamp',['timestamp',['../class_fat16.html#a4e05378c85d6c023c23835dbe69e37a9',1,'Fat16']]],
  ['truncate',['truncate',['../class_fat16.html#a3423d0cc61e29087fcc82236b6085e24',1,'Fat16']]]
];
