var searchData=
[
  ['errorcode',['errorCode',['../class_sd_card.html#aa6df95cb73abaffa0e152055b8886b99',1,'SdCard']]],
  ['errordata',['errorData',['../class_sd_card.html#a499e5e25d2dfaf1dc77b5845fb8d9438',1,'SdCard']]]
];
