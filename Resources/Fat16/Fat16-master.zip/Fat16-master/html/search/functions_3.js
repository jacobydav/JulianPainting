var searchData=
[
  ['fat16',['Fat16',['../class_fat16.html#a541767c29586dd7a007ddc276025bf2c',1,'Fat16']]],
  ['fgets',['fgets',['../class_fat16.html#ab3859092bf25fe423988b8f562084d7b',1,'Fat16']]],
  ['filesize',['fileSize',['../class_fat16.html#a8018bb2e144e33806802fdf2d944e3c0',1,'Fat16']]],
  ['freeram',['FreeRam',['../_fat16util_8h.html#a6bb5e041af7696bbf74a0517bbfe4d0f',1,'Fat16util.h']]]
];
