var searchData=
[
  ['fat',['fat',['../unioncache16__t.html#a76884aee392753e77c852508096e4447',1,'cache16_t']]],
  ['fbs',['fbs',['../unioncache16__t.html#acaee53c6c7d35746b0d42db8536e376b',1,'cache16_t']]]
];
