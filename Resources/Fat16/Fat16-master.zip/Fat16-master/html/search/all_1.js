var searchData=
[
  ['begin',['begin',['../class_sd_card.html#a3f5240d2ab00ef262b6a566147fb762c',1,'SdCard']]]
];
