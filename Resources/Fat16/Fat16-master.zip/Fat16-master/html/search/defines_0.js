var searchData=
[
  ['fat16_5fdebug_5fsupport',['FAT16_DEBUG_SUPPORT',['../_fat16_config_8h.html#a618f37288bd16c11fcc5d677d1d83c6f',1,'Fat16Config.h']]],
  ['fat16_5fversion',['FAT16_VERSION',['../_fat16_8h.html#ad856cd5d226499d9c5ab83f987d5d7ed',1,'Fat16.h']]]
];
