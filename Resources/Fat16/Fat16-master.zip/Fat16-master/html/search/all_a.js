var searchData=
[
  ['open',['open',['../class_fat16.html#a66a1f8de2b84b7a41dbaa86104e28111',1,'Fat16::open(const char *fileName, uint8_t oflag)'],['../class_fat16.html#a662a3b841d02e8bf0f0ae673cc1d7691',1,'Fat16::open(uint16_t entry, uint8_t oflag)']]]
];
