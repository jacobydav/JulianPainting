var searchData=
[
  ['read',['read',['../class_fat16.html#ad0b43c1c92d6c3588cd62504066c8739',1,'Fat16::read(void)'],['../class_fat16.html#a7e9150101ccd6f41ac349f108239438e',1,'Fat16::read(void *buf, uint16_t nbyte)']]],
  ['readblock',['readBlock',['../class_sd_card.html#a58e792e317444fa294b7ad236bbd7dbf',1,'SdCard']]],
  ['readcid',['readCID',['../class_sd_card.html#a0422c032f9a91892225ff4997a153e55',1,'SdCard']]],
  ['readdir',['readDir',['../class_fat16.html#ab36ceb72680fc2ebf71af8a0f09bbd83',1,'Fat16']]],
  ['remove',['remove',['../class_fat16.html#a5162e76818458e283b6526b14f116129',1,'Fat16::remove(void)'],['../class_fat16.html#a622ea8895a6ba2a1ba374ca7ba7ce0d4',1,'Fat16::remove(const char *fileName)']]],
  ['rewind',['rewind',['../class_fat16.html#ad9a5558c406905c1e38fbee7dc76e98f',1,'Fat16']]],
  ['rootdirentrycount',['rootDirEntryCount',['../class_fat16.html#aab4922c434b1642cac213705d814de4c',1,'Fat16']]]
];
